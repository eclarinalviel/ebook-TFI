<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="ICT Learning Management System">
        <meta name="author" content="TechFactors Inc.">
        <title><?= $page_title ?> | ICT</title>
        <link rel="shortcut icon" href="<?= base_url('assets/images/ico/favi.ico'); ?>">
        <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css'); ?>" />
        <link rel="stylesheet" href="<?= base_url('assets/fontawesome/css/font-awesome.min.css'); ?>" />
        <link rel="stylesheet" href="<?= base_url('assets/pace/css/themes/flash.min.css'); ?>" />
        <link rel="stylesheet" href="<?= base_url('assets/base/animate.min.css'); ?>" />
        <link rel="stylesheet" href="<?= base_url('assets/icheck/skins/all.css'); ?>" />
        <link rel="stylesheet" href="<?= base_url('assets/base/chosen.css'); ?>"/>
        <link rel="stylesheet" href="<?= base_url('assets/base/dist/css/base.min.css'); ?>" />
        
        <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if late IE 9]>
        <script type="text/javascript" src="<?= base_url('assets/js/html5shiv.js'); ?>"></script>
        <script type="text/javascript" src="<?= base_url('assets/js/respond.min.js'); ?>"></script>
        <![endif]-->
        
    </head>
    <body style="background-color: #E0E4CC;">