<!-- Top Navigation -->
<?= $this->load->view('topnav', '', TRUE) ?>

<div class="container-fluid" style="background-color: #E0E4CC; padding-bottom: 50px">
    <div class="row">       
        
       <!-- Main Content -->
       <div class="col-sm-9 col-md-10 main" style="margin-left: 10%;">
            <h2 class="page-title"><?php if (isset($success_msg)) { echo $success_msg; } ?></h2>
                
            <div class="tab-content white-bg" style="background-color: transparent; padding: 0; border: 0;">

                        <div class="row">
                            <div class="col-xs-8 col-sm-6 col-md-4 col-lg-3">
                                <div class="thumbnail">
                                    
                                    <a href="" data-toggle="modal" data-target="#myModal">
                                        <img src="<?= base_url('assets/images/thumbnails/thumb1.jpg') ?>" alt="documuents">
                                    </a>
                                    <div class="caption">
                                        <h5 class="ellipsis"><strong>Web Scripting 2nd Edition Miriam College</strong></h5>
                                    </div>
  
                                </div>
                            </div>
                            <?= $this->load->view('modal', '', TRUE) ?>
                        </div>
                              
            </div>
         
        </div>

    </div>
</div>

<nav class="navbar navbar-inverse navbar-fixed-bottom" style="background-color: #4D968A; height: 75px; border: none; padding-top: 10px;">    
    <a href="http://www.techfactors.com/" style="margin-left: 45%; margin-right: 45%;">
        <img src="<?= base_url('assets/images/logo/main.png') ?>" alt="ICT"/>
    </a>
</nav>