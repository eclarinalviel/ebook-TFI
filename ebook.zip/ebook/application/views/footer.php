<!-- Loading JS Libraries -->
<script type="text/javascript" src="<?= base_url('assets/js/jquery-2.1.0.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/holder.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/pace.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/icheck.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/wow.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/jquery.timeago.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/tinymce/js/tinymce/tinymce.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/chosen.jquery.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/base.min.js'); ?>"></script>

</body>
</html>