<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color: #F38630; border: none">    

    <h2 class="page-title" style="margin-left: 10%; color: #FFF"><strong>E-BOOK</strong></h2>
    
</nav>