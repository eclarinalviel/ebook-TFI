<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header"><strong>Web Scripting 2nd Edition Miriam College</strong></div>
      <div class="modal-body">
        <?php echo form_open_multipart('verification/check');?>

        <fieldset>    
            <input type="hidden" value="b9c4fa2eb23754032ce5c4407b54efa6" name="pass">
            <div class="form-group">
                <div class="row">
                    <div class="col-md-12">
                        <label for="title">Password</label>
                        <input type="password" class="form-control" id="password" placeholder="********" name="password">
                    </div>
                </div>
            </div>

        </fieldset>

        <button type="submit" class="btn btn-primary">Download</button>
        <?php echo form_close(); ?>

      </div>
      <div class="modal-footer">

        <form action="<?= base_url('home')?>">

        <button type="submit" class="btn btn-default">Close</button>
        </form>

      </div>

    </div>

  </div>
</div>