<?php

class Files_Model extends CI_Model
{

    public $tbl;

    public function __construct()
    {
        parent::__construct();

    }

    public function _get_docs($topic_id){
        $this -> db -> select('*');
        $this -> db -> from('tbl_tg_pass');
        $this -> db -> where('topic_id',$topic_id);

        $query = $this-> db -> get();
        return ($query -> num_rows() > 0) ? $query -> result() : false;
    }



}

/* End of file: Authme_model.php */
/* Location: application/models/Authme_model.php */