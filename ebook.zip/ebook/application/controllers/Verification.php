<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Verification extends CI_Controller {

    public $file_id;
    public $topic_id;
    public $temp;

    
    public function __construct() {
        parent::__construct();
        $this->load->helper('download');
    }

    
    public function check() {
        $pass = md5($this -> input -> post('password'));
        $checker = $this -> input -> post('pass');
        
        if($pass == $checker){
            $data = file_get_contents(base_url('assets/documents/Web_Scripting_2nd_Edition_Miriam_College.pdf')); // Read the file's contents
            $name = 'Web Scripting 2nd Edition Miriam College.pdf';
            
            force_download($name, $data);
            
        }
        else {
            
            $obj = array(
            'page_title' => 'E-Book',
            );
            
            $data['success_msg'] = '<div class="alert alert-danger">The password is incorrect!!!</div>'; 
            
            $this->load->view('header',$obj);
            $this->load->view('index',$data);
            $this->load->view('footer');
        }

    }

}

/*
* end of file
* location: controllers/scores.php
*/

    
